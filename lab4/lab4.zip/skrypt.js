console.log('\x1B[31mWitaj Świecie\x1B[0m\n');
