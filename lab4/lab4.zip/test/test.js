/* eslint-disable max-len */
/* eslint-disable no-undef */
/*
  // eslint-disable-next-line max-len
  Mocha allows you to use any assertion library you wish. In this example, we are using the built-in module called 'assert'.
  If you prefer the 'chai' library (https://www.chaijs.com/) then you have to install it yourself: 'npm install chai --save-dev',
  and then you need to uncomment the lines below.
*/

// var expect = require('chai').expect;
// const assert = require('assert');
// const Operation = require('../module');

// // eslint-disable-next-line no-undef
// describe('The sum() method', () => {
//   // eslint-disable-next-line no-undef
//   it('Returns 4 for 2+2', () => {
//     const op = new Operation(2, 2);
//     assert.strictEqual(op.sum(), 4);
//     // expect(op.sum()).to.equal(4);
//   });
//   it('Returns 0 for -2+2', () => {
//     const op = new Operation(-2, 2);
//     assert.strictEqual(op.sum(), 0);
//     // expect(op.sum()).to.equal(0);
//   });
// });
